var boxContentID = 0;

function setReviewContent(src)
{
	var text = contentList[src][1];
	var rating = parseInt(contentList[src][2]);
	rating = (rating*2) * 23;
	$('div.reviewQuote').html(text.substring(0,300)+'...');
	$('div.reviewAuthor').html(contentList[src][4]);
	$('div.reviewImage img').attr('src', contentList[src][3]);
	$('div.reviewRating img').css('top', '-'+rating+'px');
	$('a#reviewLink').attr('href', 'reviews/'+contentList[src][0]+'/');
}

function strpos (haystack, needle, offset) {
  // http://kevin.vanzonneveld.net
  // +   original by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
  // +   improved by: Onno Marsman
  // +   bugfixed by: Daniel Esteban
  // +   improved by: Brett Zamir (http://brett-zamir.me)
  // *     example 1: strpos('Kevin van Zonneveld', 'e', 5);
  // *     returns 1: 14
  var i = (haystack + '').indexOf(needle, (offset || 0));
  return i === -1 ? false : i;
}
	
	function deleteFromCompare(target)
	{
		$('div.mask').fadeIn('fast');
		$('div.compareView').fadeOut('fast');
		var num = $('div.compareViewTab').html();
		num = num.replace('Compare (','');
		num = num.replace(')','');
		num = parseInt(num, 10);
		
		var ids = target;
		idsArray = ids.split('-');
		
		$.ajax({
			cache: false,
			type: 'POST',
			data: 'action=delete_from_compare&deleteHolidayID='+idsArray[0]+'&deleteAccommodationID='+idsArray[1],
			url: 'add_to_compare.php',
			success: function(data){
				$('div#'+ids).parent().css('display','none');
				$('div.compareViewTab').html('Compare ('+(num-1)+')');
				$('div.mask').fadeOut('fast');
				$('div.compareView').fadeIn('fast');
			
				if((num) == 5)
				{
					$("div.buttonCompare").css('display', 'block');
					$("div.buttonDisabledCompare").css('display', 'none');
				}
		   }
		});
	}


$(document).ready(function(){  

	var stop = false;
							   
	$('div.socialIcon').mouseenter(function() {
		$(this).find('img').css('top', '-44px');
	}).mouseleave(function() {
		$(this).find('img').css('top', '0px');
	});
							   
	$('div.navItem').mouseenter(function() {
		$(this).find('div.dropdown').slideDown('fast');
	}).mouseleave(function() {
		$(this).find('div.dropdown').slideUp('fast');
	});
							   
	$('div.dropdownItem').mouseenter(function() {
		$(this).find('div.dropdownSub').slideDown('fast');
	}).mouseleave(function() {
		$(this).find('div.dropdownSub').slideUp('fast');
	});
	
	$('div.compareViewTab').click(function() {
		
		var pos;
		if($('div.compareView').css('bottom') == '0px')
			pos = '-150px';
		else
			pos = '0px';
			
		$.ajax({
			cache: false,
			type: 'POST',
			url: '/js/set-compare-viewable.php',
			data: 'pos='+pos,
			success: function(){
			}
		});
		
		if($('div.compareView').css('bottom') == '0px')
		{
			$('div.compareView').animate({ bottom:'-150px'}, 200);
			$('div.compareViewTab').css('background-position','0px -36px');
		}
		else
		{
			$('div.compareView').animate({ bottom:'0px'}, 200);
			$('div.compareViewTab').css('background-position','0px 0px');
		}
		
	});
	
	//Custom dropdowns
	$('input.dropDown').click(function() {	
		$('div.inputOptions').slideUp('fast');
		$(this).parent().find('div.inputOptions').slideDown('fast');	
	});	
	$('div.inputOptions').mouseleave(function() {	
		//$(this).slideUp('fast');	
	});	
	$('div.inputOptionsItem').click(function() {	
		$(this).parent().parent().find('input.dropDown').attr('value', $(this).html());
		$(this).parent().parent().find('input.hiddenVal').attr('value', $(this).attr('rel'));
		$(this).parent().slideUp('fast');	
	});
	
	
	
	$('div.expand').mouseenter(function() {
		if($(this).parent().find('div.roomDetailsText').css('display') == 'none')
		{
			$(this).css('background-position', '-22px 0px');
		}
		else
		{
			$(this).css('background-position', '-22px -20px');
		}
	}).mouseleave(function() {
		if($(this).parent().find('div.roomDetailsText').css('display') == 'none')
		{
			$(this).css('background-position', '0px 0px');
		}
		else
		{

			$(this).css('background-position', '0px -20px');
		}
	});
	
	$('div.expand').click(function() {
		if($(this).parent().find('div.roomDetailsText').css('display') == 'none')
		{
			$(this).parent().find('div.roomDetailsText').slideDown('fast');
			$(this).css('background-position', '-22px -20px');
		}
		else
		{
			$(this).parent().find('div.roomDetailsText').slideUp('fast');
			$(this).css('background-position', '-22px 0px');
		}
	});
	
	
	$('div.holidaySliderControl').mouseenter(function() {
		$(this).css('background-position', '0px -50px');
	}).mouseleave(function() {
		$(this).css('background-position', '0px 0px');
	});
	
	
	$('div.boxArrows div').mouseenter(function() {
		$(this).css('background-position', '0px -34px');
	}).mouseleave(function() {
		$(this).css('background-position', '0px 0px');
	});
	
	$('div.boxArrowPrev').click(function() {
		boxContentID--;
		
		if(boxContentID < 0)
			boxContentID = (numContent-1);
		
		setReviewContent(boxContentID);
	});
	
	$('div.boxArrowNext').click(function() {
		boxContentID++;
		
		if(boxContentID > (numContent-1))
			boxContentID = 0;
		
		setReviewContent(boxContentID);
	});
	
	
	
	
	$('div.featureBox').mouseenter(function() {
		$(this).find('div.featureBoxRooms').fadeOut('fast');
		$(this).find('div.featureBoxTooltip').fadeIn('fast');
	}).mouseleave(function() {
		$(this).find('div.featureBoxTooltip').fadeOut('slow');
		$(this).find('div.featureBoxRooms').fadeIn('slow');
	});
	
	
	
	function slide(dir, slide)
	{
		if(!stop)
		{
			stop = true;
		var curPos = $('div.holidaySliderInner').css('left');
		
		if(dir == 'next')
		{
			if(Math.abs(curPos.replace('px','')) < (((numSlides-1)*161)-956))
			{
				curPos = parseInt(curPos) - 161;
			
				if(Math.abs(curPos) >= (((numSlides-1)*161)-956))
					$('div.holidaySliderRight').animate({ opacity: 0}, 800);
				if($('div.holidaySliderLeft').css('opacity') == 0)
					$('div.holidaySliderLeft').animate({ opacity:1.0}, 800);
			}
		}
		else if(dir == 'prev')
		{
			if(curPos.replace('px','') < 0)
			{
				curPos = parseInt(curPos) + 161;
				
				if(curPos == 0)
					$('div.holidaySliderLeft').animate({ opacity: 0}, 800)
				if($('div.holidaySliderRight').css('opacity') == 0)
					$('div.holidaySliderRight').animate({ opacity:1.0}, 800);
			}
		}
		
		$('div.holidaySliderInner').animate({ left: ''+curPos+''}, 800);
		stop = false;
		}
	}
	
	$('div.holidaySliderLeft').click(function() {
		slide('prev');
	});
	
	$('div.holidaySliderRight').click(function() {
		slide('next');
	});
	
	$('div.slideshowControl').mouseenter(function() {
		$(this).css('background-position', '0px -50px');
	}).mouseleave(function() {
		$(this).css('background-position', '0px 0px');
	});
	
	$('div.accommodationThumbsItem').click(function() {
		var target = $(this).attr('rel');
		
		$('div.accommodationChoicesItem').fadeOut('fast');
		$('div#'+target).fadeIn('fast');
		
		var accommodationID = $(this).find('img').attr('rel');
		
		currentActivitySlide = 'accommodationActivitiesSlide'+accommodationID+'-1';
	});
	
	function accommSlide(dir, slide)
	{
		if(!stop)
		{
			stop = true;
			var curPos = $('div.accommodationThumbsInner').css('left');
			
			if(dir == 'next')
			{
				if(Math.abs(curPos.replace('px','')) < (((numAccommThumbs-1)*150)-956))
				{
					curPos = parseInt(curPos) - 900;
				
					if(Math.abs(curPos) >= (((numAccommThumbs-1)*150)-956))
						$('div.accommodationControlRight').animate({ opacity: 0}, 800);
					if($('div.accommodationControlLeft').css('opacity') == 0)
						$('div.accommodationControlLeft').animate({ opacity:1.0}, 800);
				}
			}
			else if(dir == 'prev')
			{
				if(curPos.replace('px','') < 0)
				{
					curPos = parseInt(curPos) + 900;
					
					if(curPos == 0)
						$('div.accommodationControlLeft').animate({ opacity: 0}, 800)
					if($('div.accommodationControlRight').css('opacity') == 0)
						$('div.accommodationControlRight').animate({ opacity:1.0}, 800);
				}
			}
			
			$('div.accommodationThumbsInner').animate({ left: ''+curPos+''}, 800);
			stop = false;
		}
	}
	
	$('div.accommodationControlLeft').click(function() {
		accommSlide('prev');
	});
	
	$('div.accommodationControlRight').click(function() {
		accommSlide('next');
	});
	
	$('div.accommodationActivitiesNext').click(function() {
		var current = currentActivitySlide;
		currentIndex = strpos(current, '-', 0);
		current = currentActivitySlide.substr(currentIndex+1);
		currentActivitySlideHold = currentActivitySlide.substr(0,currentIndex+1);
		current = parseInt(current);
		current++;
		if($('div#'+currentActivitySlideHold+current).length > 0)
		{
			currentActivitySlide = currentActivitySlideHold+current;
			$('div.accommodationActivitiesSlide').fadeOut('fast');
			$('div#'+currentActivitySlide).fadeIn('fast');
		}
	});
	
	$('div.accommodationActivitiesPrev').click(function() {
		var current = currentActivitySlide;
		currentIndex = strpos(current, '-', 0);
		current = currentActivitySlide.substr(currentIndex+1);
		currentActivitySlideHold = currentActivitySlide.substr(0,currentIndex+1);
		current = parseInt(current);
		current--;
		if(current > 0)
		{
			currentActivitySlide = currentActivitySlideHold+current;
			$('div.accommodationActivitiesSlide').fadeOut('fast');
			$('div#'+currentActivitySlide).fadeIn('fast');
		}
	});
	
	
	
	
});